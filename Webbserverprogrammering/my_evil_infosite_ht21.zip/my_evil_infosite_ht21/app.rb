# Avstämning v42-43. Din egen Evil data infosite.
# Sidan ska visa upp (hemlig?) information om människor utifrån data i csv-fil.
# Enskild uppgift, men samarbetsgrupper om 3 (så vi kan hjälpa varandra).
# Uppgiften liknar tidigare veckor men mer frihet. Fri CSS, fri struktur i slim-filer.
# Frihet att välja vilken data du vill visa upp.
# Inlämning på classroom v43: Film/bild på resultat. Självutvärdering

# 1. Require gems...

# 2. Skapa en route...

# 3. Hämta data från data/evil_data.csv i routen. Strukturera om datan likt annonser och contact cards [{},{},{}...] 
# Man får gärna gå in på mockaroo.com och ladda ner en egen
# csv-fil. Se upp med data som innehåller ",", kan ställa till problem vid mapning

# 4. Visa upp din data via slim och valfri css

# 5. v.43 lägger vi till en evil calculator till sidan. Moahahaha!


