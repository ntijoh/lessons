require 'sinatra'
require 'slim'

get('/') do

  

  # 1: Hämta alla data ifrån 'data/user_data.csv'
  lines = File.readlines('data/annonser.csv')

  # 2: Gör om datastrukturen till en ny dubbelarray. Tips: map, split.
  
  double_array =

  # 3: Utgå från dubbellarrayen (#2) och skapa ännu
  # en ny array som innehåller 1 dictionary/anställd. Tips: map

  array_with_hashes = 

  # 4: Kolla hur data är strukturerad
  p array_with_hashes 

  # 5: Här anropar du slim (:grillkorv). I locals skickar du med array_with_hashes
  
  # 6: Finslipa SLIM-kod i slim-filerna så att resultatet efterliknar
  # html-koden i evilthsirts.html (ligger i public-mappen)

end

