require 'sinatra'
require 'slim'

get('/') do

  

  # 1: Hämta alla data ifrån 'data/user_data.csv'
  lines = File.readlines('data/annonser.csv')

  # 2: Gör om datastrukturen till en ny dubbelarray
  double_array = lines.map do | annons_string |
    annons_string.split(',')
  end

  # 3: Skapa ännu en ny array som innehåller 1 dictionary/anställd

  array_with_hashes = double_array.map do | annons_array |
    human = {
      id:annons_array[0],
      email:annons_array[1],
      username:annons_array[2],
      money:annons_array[3],
      car_model:annons_array[4],
      animal:annons_array[5],
      city:annons_array[6],
      avatar:annons_array[7]
    }
  end
  # 4: Kolla hur data är strukturerad
  p array_with_hashes 

  # 5: Skapa SLIM-kod i slim-filerna (/viems/)

  # 6: Här skapas html mha slim. Dictionaryn 'data_hash' skickas med (alla anställda)
  slim(:grillkorv, locals:{banankey:array_with_hashes}) #:index är namnet på slim-fil. datahash är en dictionary vi skickar.

end

