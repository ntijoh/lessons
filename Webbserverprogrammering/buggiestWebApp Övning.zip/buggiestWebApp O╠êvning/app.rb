require 'slim'
require 'sinatra'
require 'sinatra/reloader'


                                                                                                                                                                                              get('/sid7') do "Chokladboll i Blå förpackning." end                                                                                                                                                                                                                                                                                                                                                                                               

get('/') do
  #Oj, inte så mycket som verkar funka. UTF? 
  slim(:start)
end
get('/sid1') do 
  #Varför blir det inga taggar?
  slim(:start)
end

get('/sid2/:foo') do
  #inte ger det rätt resultat...
  list = ["Show me this", "Don't show me this", "I'm hiding"]
  @foo = list[params[:foo]]
  
  slim(:sid2)
end
get('/sid3') do
  "<h3>En gammel sida som leder tillbaks</h3>"
  "<a href="/sid1"> Tillbaks till sida 1</a>"
  
end

get('/sid4/frukt') do
  #bananer?
  @smaskens = params[frukt]

  slim(:sid4)
end

get('/sid5') do
  #Hamnat rätt?
  slim(:sid5)
end

get('/sid6') do
  #Visar en bild
  slim(:sid6)
end

get('/sid7') do
  #Gul eller blå?
  @data = "Chokladboll i Gul förpackning."
  slim(:sid7)
end


get('/sid8') do
  #Looper
  @data = [
    {
      name:"Bo",
      city:"New Jersey",
      "age"=>3

    },
    {
      name:"Bodil",
      city:"New York",
      "age"=>"31"
      
    },
    {
      name:"Borelia",
      city:"Borås",
      "age"=>"345"
      
    }
  ]
  slim(:sid8)
end
get('/sid9') do
  #Condition: 100images
  slim(:sid9)
end

get('/sid10') do
  #Show me the person!
  slim(:person)
end

get('/sid10') do
  slim(:"persons/person")
end

get('/sid11') do
  #Strunta i vad som händer här...
  db = SQLite3::Database.new("db/employees.db")
  db.results_as_hash = true #Få svar i strukturen [{},{},{}]
  @result = db.execute("SELECT * FROM employees")
  #... til hit (databasanrop)
  p @result
  
  slim(:sid11)
end
